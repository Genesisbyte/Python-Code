# Title: Fighting Game List
# Author: GenesisByte
# Date: 04-Feb-2024
# Description: Searching and adding to a list with recursion

# Creating a list with 20 elements
smashbrosList = ["samus", "pikachu", "fox", "kazuya", "sonic", "mario", "zelda", "kirby", "terry", "simon",
                 "link", "ridley", "samus", "lucas", "sora", "ness", "snake", "richter", "mewtwo", "ganondorf"]


# Procedure to search for an item in the list
def SearchItem(smashbrosList):
    searchInput = input(
        "Enter word: (Type q to quit) ").lower()  # Ask the user to enter a word or type escape to quit. .lower() to force lowercase input
    if searchInput.upper() == "Q":  # If user types escape quit the program
        return
    if searchInput in smashbrosList:  # If user enters a word that is in the list
        print("Item found at position: ", smashbrosList.index(searchInput))

    elif searchInput.isdigit():  # Check if input has a number in it and displays this error
        print("Enter words only! Try Again!")
    else:
        print("Item not found")  # Otherwise this message will display and return to the start of the program
    print(f"You entered {searchInput}")  # Displaying the word that the user entered (can be used for spelling errors)
    SearchItem(smashbrosList)  # Recursion for repeatedly asking the user if they want to search or quit


def AddItem(smashbrosList):
    addChoice = input(
        "Enter a word to add: Or q to quit?").lower()  # Ask the user to enter a word to add or type escape to quit. .lower() to force lowercase input
    if addChoice.upper() == "Q":  # If user types escape quit the program
        return
    elif addChoice.isdigit():  # Check if input has a number in it and displays this error
        print("Enter words only! Try Again")
    else:  # If above options arent correct then item added to list with .append() with parameter of the input
        smashbrosList.append(addChoice)  # Adding the items to the list
        print(f"You entered {addChoice}")  # Display  what the user entered
        print("Item added to list!")  # Display message saying it has been successfully added
        print(f"Current List: {smashbrosList}")  # Display list with added item(s)
    AddItem(smashbrosList)  # Recursion for repeatedly asking the user if they want to search or quit


# Calling the procedures with the parameter of the list
SearchItem(smashbrosList)
AddItem(smashbrosList)

# Programmer Notes
# len: number of items in a list
# .split(): splits string into a list
# if user wants to keep it to 1 word responses they could use:
# if len(addChoice.split())>1:      print("1 word only!")
# if length of the user word to be added 'list' is greater than 1 print an error message saying to only enter 1 word














