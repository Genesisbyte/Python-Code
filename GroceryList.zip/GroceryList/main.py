# Title: Adding to Grocery List
# Author: Genesisbyte
# Date: 05-Feb-2024
# Description: Two lists

basket = ["Apple", "Bun", "Cola"]  # Creating the "basket" list with requested items
crate = ["Egg", "Fig", "Grape"]  # Creating the "crate" list with requested items
print(f"Basket List: {basket}")  # Printing the "basket" list
print(f"Crate List: {crate}")  # Printing the "crate" list


# Error m procedure
def ErrorMessage(e):
    print("Item not found! Try again!")


# Procedure to add items to lists
def AddItemsToLists(basket, crate):
    addInput = input(
        "Which list would you like to add to? Type Basket or Crate or type Q to quit: ")  # Prompt user to enter an item or press q to quit
    if addInput.upper() == "Q":  # If user enters q or Q program will quit
        return
    elif addInput.upper() == "BASKET":  # If user enters basket or BASKET...
        basketAdd = input("Enter word to add to basket: ")  # ...Prompt to add word to basket list
        if basketAdd.isdigit():  # If user enters a number...
            print("Enter words only! Try Again!")  # ...This message will display
        else:
            basket.append(basketAdd)  # Otherwise the input has been added to the list
            print(f"{basketAdd} added to list!")  # Informing the user that the input has been added
            print(f"Current list for basket:{basket}")  # Displaying what the basket list looks like as of that point

    elif addInput.upper() == "CRATE":  # If user enters crate or CRATE...
        crateAdd = input("Enter word to add to crate: ")  # ...Prompt to add word to crate list
        if crateAdd.isdigit():  # If user enters a number..
            print("Enter words only! Try Again!")  # ...This message will display
        else:
            crate.append(crateAdd)  # Otherwise add the input to the crate list
            print(f"{crateAdd} added to list!")  # Informing the user that the input has been added
            print(f"Current list for crate:{crate}")  # Display what the crate list looks like as of that point

    AddItemsToLists(basket, crate)  # Using recursion to repeat the procedure until q has been quit


# Procedure to remove items from lists
def RemoveItemsFromLists(basket, crate):
    removeInput = input(
        "Which list would you like to remove from? Type Basket or Crate or type q to quit: ")  # Prompt the user which list they want

    if removeInput.upper() == "Q":  # If user enters q program ends
        return

    elif removeInput.upper() == "BASKET":  # If users enters basket
        try:
            basketRemove = input("Enter item to be removed from basket: ")  # Try to ask which word they want to remove
            basket.remove(basketRemove)  # Try to remove input from the basket list
        except ValueError as e:  # If item inputted is not in list display error message calling from ErrorMessage procedure
            ErrorMessage(e)
        else:
            print(f"{basketRemove} has been removed!")  # Informing the user that the item has been removed
            print(f"Current list for basket:{basket}")  # Displaying what the basket list looks like as of that point

    elif removeInput.upper() == "CRATE":  # If user enters crate.
        try:  # Try to
            crateRemove = input("Enter item to be removed from crate: ")  # Ask for item to be removed
            crate.remove(crateRemove)  # If item is not in the list to be removed
        except ValueError as e:  # Display error message calling from ErrorMessage procedure
            ErrorMessage(e)
        else:  # Otherwise
            print(
                f"{crateRemove} has been removed from list!")  # Informing the user that the word has been removed from crate list
            print(f"Current list for crate:{crate}")  # Displaying what the crate list looks like to that point
    RemoveItemsFromLists(basket, crate)  # Using recursion to repeat the procedure until q has been entered


# Procedure for displaying the lists after adding or removing items
def DisplayFinalLists(basket, crate):
    showbasketInput = input(
        "Enter list to look at: Basket or Crate or type Q to quit")  # Prompt user to ask which list they want
    if showbasketInput.upper() == "BASKET":  # If user enters basket
        print(f"Basket List:{basket}")  # Display list of basket
    elif showbasketInput.upper() == "CRATE":  # If user enters crate
        print(f"Crate List:{crate}")  # Display list of crate
    elif showbasketInput.upper() == "Q":  # If user enters q
        return  # Exit the program
    else:
        print("Enter from the options only!")  # Otherwise this message will display
    DisplayFinalLists(basket, crate)  # Using recursion to repeat the procedure until q has been entered


# Calling the procedures
AddItemsToLists(basket, crate)
RemoveItemsFromLists(basket, crate)
DisplayFinalLists(basket, crate)

