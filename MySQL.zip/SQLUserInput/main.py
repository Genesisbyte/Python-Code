# Title: SQL With User Input
# Author: Genesisbyte
# Date: 22-Feb-24
# Description: Creating a mysql database from user input

# Libraries
from tkinter import *
import tkinter.messagebox as box
import sqlite3

# Create instance
win = Tk()


# Procedure to name and resize the window
def windowsize(title):
    win.title(title)  # Creating the title to be edited
    win.geometry("1000x900")  # Window size of 1000x900 (height x width)


# Procedure to display label
def displaylabel(lbl):
    label = Label(win, text=lbl, font=("Arial", 25))
    label.place(x=175, y=30)


# Procedure to display error
def displayerror(x):
    box.showerror("Error", x)  # Display error messagebox


# Procedure to create and display the outcome
def displaymessage(x):
    box.showinfo("Info", x)  # Display info messagebox


# Procedure to quit the program
def quitprogram():
    quit()  # Quit the program


# Procedure to create and display the quit button
def exitbutton():
    qButton = Button(win, text="Exit", command=quitprogram)  # Create the quit button when pressed program will quit
    qButton.pack()  # Display the button and placed at 225 by 350


# Procedure to clear the entries after submitting
def checkfile():
    x = filenameEntry.get()
    if ".db" in x:
        displaymessage("Database Created!")
    else:
        displayerror("Database not created!")


def checkentry():
    a = filenameEntry.get()
    b = genreEntry.get()
    c = gameEntry.get()
    d = publishEntry.get()
    e = platEntry.get()
    f = salesEntry.get()

    if b.isnumeric() or c.isnumeric() or d.isnumeric() or e.isnumeric() or f.isalpha():
        displayerror("Invalid Input")


# Procedure to create the database
def database():
    filename = filenameEntry.get()
    genre = genreEntry.get()
    game = gameEntry.get()
    publisher = publishEntry.get()
    platform = platEntry.get()
    region = regionChoice.get()
    sales = salesEntry.get()
    conn = sqlite3.connect(filename)
    cursor = conn.cursor()
    cursor.execute(
        f"CREATE TABLE IF NOT EXISTS [{filename}] ( genre TEXT, game TEXT,publisher TEXT,platform TEXT,region TEXT,sales INT)")
    cursor.execute(f"INSERT INTO [{filename}] VALUES (?,?,?,?,?,?)", (genre, game, publisher, platform, region, sales))
    conn.commit()
    for row in cursor.execute(f"SELECT genre,game,publisher,platform,region,sales FROM [{filename}]"):
        displaymessage(row)


# Main

# Creating file name entry
filenameLabel = Label(win, text="Enter database name", font=("Arial", 10))
filenameLabel.pack()
filenameEntry = Entry(win)
filenameEntry.pack()

# Creating genre entry
genreLabel = Label(win, text="Enter genre:")
genreLabel.pack()
genreEntry = Entry(win)
genreEntry.pack()

# Creating title entry
gameLabel = Label(win, text="Enter game title:")
gameLabel.pack()
gameEntry = Entry(win)
gameEntry.pack()

# Creating publisher entry
publishLabel = Label(win, text="Enter publisher:")
publishLabel.pack()
publishEntry = Entry(win)
publishEntry.pack()

# Creating platform entry
platLabel = Label(win, text="Enter platform:")
platLabel.pack()
platEntry = Entry(win)
platEntry.pack()

# Creating a dropdown list/menu of regions game sold
regionList = ["China", "United States", "South Korea", "United Kingdom", "France", "Canada", "Brazil", "Italy", "Japan",
              "Germany"]
regionChoice = StringVar()
droplist = OptionMenu(win, regionChoice, *regionList)
regionChoice.set("Select Country")
droplist.config(width=15)
droplist.pack()

# Creating sales input
salesLabel = Label(win, text="Enter sales:")
salesLabel.pack()
salesEntry = Entry(win)
salesEntry.pack()

# Calling procedure to name the window
windowsize("Database")

# Create button to submit data
Btn = Button(win, text="Submit", command=lambda: ([database(), checkfile(), checkentry()]))
Btn.pack()

# Call exit button procedure
exitbutton()

win.mainloop()



