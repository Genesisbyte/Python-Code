# Title:Banking Database
# Author: Genesisbyte
# Date: 25-Feb-24
# Description: History of transactions

from tkinter import *
import tkinter.messagebox as box
import sqlite3

# Create instance
win = Tk()

#Procedure to name and resize the window
def windowsize(title):
    win.title(title)                                    #Creating the title to be edited
    win.geometry("500x400")                             #Window size of 500x400 (height x width)
    #win.configure(bg='black')                          #Change colour of window with this

#Procedure to display label
def displaylabel(lbl):
    label=Label(win,text=lbl,font=("Arial",25))
    label.place(x=225,y=0)                              #Display label at 225 x 0

#Procedure to display error
def displayerror(x):
    box.showerror("Error",x)                            #Display error messagebox

#Procedure to create and display the outcome
def displaymessage(x):
    box.showinfo("Info",x)                              #Display info messagebox

#Procedure to quit the program
def quitprogram():
    quit()                                              #Quit the program

#Procedure to create and display the quit button
def exitbutton():
    qButton=Button(win,text="Exit",command=quitprogram) #Create the quit button when pressed program will quit
    qButton.place(x=225,y=200)                          #Display the button and placed at 225 x 200

#Procedure to delete entries after inputting
def reset():
    nameE.delete(0,END)                                 #Delete name input field after entry starting from value 0 to END
    depositEntry.delete(0,END)                          #Delete deposit input field after entry starting from value 0 to END
    withdrawEntry.delete(0,END)                         #Delete withdraw input field after entry starting from value 0 to END

#Procedure to create table
def createtable():
    name=nameE.get()                                    #Set name entry input to name
    dep=depositEntry.get()                              #Set deposit entry input to dep
    wdraw=withdrawEntry.get()                           #Set withdraw entry input to wdraw
    if name.isnumeric() or dep.isalpha() or wdraw.isalpha():    #If name contains number or deposit/withdraw contains words
        displayerror("Invalid input!")                           #Then display error
    else:
        conn = sqlite3.connect("bank.db")               #Create database file named bank
        cursor = conn.cursor()                          #Create cursor
        cursor.execute('CREATE TABLE IF NOT EXISTS bank(name TEXT,deposit INT,withdraw INT,startingbalance INT GENERATED ALWAYS AS (0), depositbalance INT GENERATED ALWAYS AS (startingbalance+deposit),withdrawbalance INT GENERATED ALWAYS AS (depositbalance-withdraw))')
        cursor.execute('INSERT INTO bank  VALUES (?,?,?)',(name,dep,wdraw)) #Insert into table values of name,deposit and withdraw entries
        conn.commit()
        for row in cursor.execute('SELECT name,deposit,withdraw,startingbalance,depositbalance,withdrawbalance FROM bank'):#Loop every row selecting from table and its contents until end
            displaymessage(row)#Display to screen in a messagebox table contents

#Main
#Creating name entry label
nameL=Label(win,text="Enter Name")
nameL.place(x=50,y=75)
nameE=Entry(win)
nameE.place(x=150,y=75)

# Creating the deposit entry label
depositLabel = Label(win, text="Deposit")
depositLabel.place(x=50,y=100)
depositEntry = Entry(win)
depositEntry.place(x=150,y=100)

# Creating the withdrawal entry label
withdrawLabel = Label(win, text="Withdraw")
withdrawLabel.place(x=50,y=125)
withdrawEntry = Entry(win)
withdrawEntry.place(x=150,y=125)

#Create submit button
createbankBtn=Button(win,text="Create Table",command=lambda:([createtable(),reset()]))
createbankBtn.place(x=225,y=175)

windowsize("Banking")
displaylabel("Banking")
exitbutton()

#Note
#Calculation is created by including GENERATED ALWAYS AS
#Balance will always be set to 0
#New balance after deposit is GENERATED AS (balance+deposit)
#Withdraw balance after deposit is (depositbalance-withdraw)

win.mainloop()