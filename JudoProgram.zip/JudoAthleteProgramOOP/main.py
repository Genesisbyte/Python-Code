# Author: Genesisbyte


from tkinter import *
import sqlite3
import tkinter.messagebox as box

# Setting win as Tk
win = Tk()
# Boolean variable for the toggle light/dark mode
status = True

# List for holding the calendar months
month_list = ["January", "February", "March", "April", "May", "June", "July", "August",
              "September", "October", "November", "December"]


# Class to set window and menu bar
class Window:
    def __init__(self):
        self.win = win
        self.menubar = Menu(win)

    # Method to create a menu_bar
    def menu_bar(self):
        fileMenu = Menu(self.menubar, tearoff=0)
        windowMenu = Menu(self.menubar, tearoff=0)
        win.config(menu=self.menubar)
        self.menubar.add_cascade(label="File", menu=fileMenu)
        self.menubar.add_cascade(label="Window", menu=windowMenu)
        fileMenu.add_command(label="Save", command=save_file)
        fileMenu.add_command(label="Quit", command=quit_program)
        windowMenu.add_radiobutton(label="Light", command=toggle)
        windowMenu.add_radiobutton(label="Dark", command=toggle)


# Class to input entry fields
class AddAthlete:
    def __init__(self):
        self.win = win
        self.idEntry = Entry(win)
        self.idEntry.place(x=300, y=80)

        self.first = Entry(win)
        self.first.place(x=300, y=100)

        self.last = Entry(win)
        self.last.place(x=300, y=120)

        self.plan = Entry(win)
        self.plan.place(x=300, y=140)

        self.weight = Entry(win)
        self.weight.place(x=300, y=160)

        self.comp_weight = Entry(win)
        self.comp_weight.place(x=300, y=180)

        self.coach = Entry(win)
        self.coach.place(x=300, y=200)

        self.comp_number = Entry(win)
        self.comp_number.place(x=300, y=220)

        self.month_choice = StringVar()
        self.drop_list = OptionMenu(win, self.month_choice, *month_list)
        self.month_choice.set("Select Month")
        self.drop_list.config(width=15)
        self.drop_list.place(x=30, y=250)


# Class which creates the database inheriting from AddAthlete
class Database(AddAthlete):
    def create_database(self):
        try:
            id_number = int(self.idEntry.get())
            first = self.first.get()
            last = self.last.get()
            plan = self.plan.get()
            weight = int(self.weight.get())
            comp_weight = int(self.comp_weight.get())
            comp_number = int(self.comp_number.get())
            coach = int(self.coach.get())
            month = self.month_choice.get()
            if coach > 20:
                raise Exception(display_error("You are only allowed 20 hours coaching per month!"))
            elif coach < 0:
                raise Exception(display_error("Enter a number between 0 and 20"))
            if plan.lower() == "beginner" and comp_number > 0:
                raise Exception(display_error("Beginners are not allowed to enter competitions!"))
            if first.isnumeric() or last.isnumeric() or plan.isnumeric():
                display_error("Enter words only!")
            if comp_number > 1:
                raise Exception("Only 1 competition can be entered a month!")
        except ValueError:
            display_error("Invalid Input!")
        else:
            con = sqlite3.connect("database2.db")
            cur = con.cursor()
            cur.execute(
                'CREATE TABLE IF NOT EXISTS database(id INT,first TEXT,last TEXT,plan TEXT,weight INT,comp_weight '
                'INT,comp_number INT,coach_hours INT,month TEXT,comp_fee NULL,coach_price NULL,plan_cost NULL,'
                'price NULL)')
            cur.execute('INSERT INTO database VALUES (?,?,?,?,?,?,?,?,?,NULL,NULL,NULL,NULL)', (
                id_number, first, last, plan, weight,
                comp_weight, comp_number, coach, month))

            beginner_price = 25.00
            intermediate_price = 30.00
            elite_price = 30.00
            coach_hours = 9.50
            comp_fee = 22.00

            beginner_cost = 25 * 4
            intermediate_cost = 30 * 4
            elite_cost = 35 * 4
            coach_cost = 9.50 * coach

            beginner_total = beginner_cost + coach_cost
            intermediate_total = intermediate_cost + coach_cost + comp_fee
            elite_total = elite_cost + coach_cost + comp_fee

            if plan.lower() == "beginner":
                cur.execute("UPDATE database SET comp_fee=? WHERE id=? ", (comp_fee, id_number))
                cur.execute("UPDATE database SET coach_price=? WHERE id=?", (coach_hours, id_number))
                cur.execute("UPDATE database SET plan_cost=? WHERE id=?", (beginner_price, id_number))
                cur.execute("UPDATE database SET price =? WHERE id =?", (beginner_total, id_number))
            elif plan.lower() == "intermediate":
                cur.execute("UPDATE database SET comp_fee=? WHERE id=? ", (comp_fee, id_number))
                cur.execute("UPDATE database SET coach_price=? WHERE id=?", (coach_hours, id_number))
                cur.execute("UPDATE database SET plan_cost=? WHERE id=?", (intermediate_price, id_number))
                cur.execute("UPDATE database SET price =? WHERE id =?", (intermediate_total, id_number))
            elif plan.lower() == "elite":
                cur.execute("UPDATE database SET comp_fee=? WHERE id=? ", (comp_fee, id_number))
                cur.execute("UPDATE database SET coach_price=? WHERE id=?", (coach_hours, id_number))
                cur.execute("UPDATE database SET plan_cost=? WHERE id=?", (elite_price, id_number))
                cur.execute("UPDATE database SET price =? WHERE id =?", (elite_total, id_number))
            else:
                raise Exception(display_error("Invalid Plan!"))
            con.commit()

    # Procedure to specify what weight category the user is
    def weight_comparison(self):
        if int(self.weight.get()) < 66:
            display_error("You are ineligible ")
        elif 66 < int(self.weight.get()) <= 73:
            display_message("You are a lightweight")
        elif 73 < int(self.weight.get()) <= 81:
            display_message("You are a light-middleweight")
        elif 81 < int(self.weight.get()) <= 90:
            display_message("You are a middleweight")
        elif 90 < int(self.weight.get()) <= 100:
            display_message("You are a light heavyweight")
        elif int(self.weight.get()) > 100:
            display_message("You are a heavyweight")

    # Procedure to reset entry fields
    def reset(self):
        self.idEntry.delete(0, END)
        self.first.delete(0, END)
        self.last.delete(0, END)
        self.plan.delete(0, END)
        self.weight.delete(0, END)
        self.comp_weight.delete(0, END)
        self.comp_number.delete(0, END)
        self.coach.delete(0, END)


# Class to update database
class UpdateDatabase:
    # Constructor with placing the entry fields
    def __init__(self):
        self.win = win
        self.id_search = Entry(win)
        self.id_search.place(x=300, y=330)
        self.first_update = Entry(win)
        self.first_update.place(x=300, y=350)
        self.second_update = Entry(win)
        self.second_update.place(x=300, y=370)
        self.weight_update = Entry(win)
        self.weight_update.place(x=300, y=390)
        self.comp_weight = Entry(win)
        self.comp_weight.place(x=300, y=410)
        self.comp_number = Entry(win)
        self.comp_number.place(x=300, y=430)
        self.coach_update = Entry(win)
        self.coach_update.place(x=300, y=450)
        self.month_update = StringVar()
        self.drop_list2 = OptionMenu(win, self.month_update, *month_list)
        self.month_update.set("Select Month")
        self.drop_list2.config(width=15)
        self.drop_list2.place(x=30, y=480)

    # Method to update first name
    def update_f_name(self):
        try:
            id_search = int(self.id_search.get())
            f_name = self.first_update.get()
            if f_name.isnumeric():
                raise Exception(display_error("Enter words only!"))
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET first=? WHERE id=?", (f_name, id_search))
            conn.commit()

    # Method to update last name
    def update_l_name(self):
        try:
            id_search = int(self.id_search.get())
            l_name = self.second_update.get()
            if l_name.isnumeric():
                raise Exception(display_error("Enter words only!"))
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET last=? WHERE id=?", (l_name, id_search))
            conn.commit()

    # Method to update the weight
    def update_weight(self):
        try:
            id_search = int(self.id_search.get())
            weight = int(self.weight_update.get())
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET weight=? WHERE id=?", (weight, id_search))
            conn.commit()

    # Method to update the competition weight
    def new_comp_weight(self):
        try:
            id_search = int(self.id_search.get())
            compWeight = int(self.comp_weight.get())
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET comp_weight=? WHERE id=?", (compWeight, id_search))
            conn.commit()

    # Method to update the month
    def new_month(self):
        try:
            id_search = int(self.id_search.get())
            month = self.month_update.get()
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET month=? WHERE id=?", (month, id_search))
            conn.commit()

    # Method to update coaching hours
    def new_coach(self):
        try:
            id_search = int(self.id_search.get())
            coach = int(self.coach_update.get())
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET coach_hours=? WHERE id=?", (coach, id_search))
            conn.commit()

    # Method to update competition number
    def new_compNumber(self):
        try:
            id_search = int(self.id_search.get())
            number = int(self.comp_number.get())
        except ValueError:
            display_error("Invalid Input")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("SELECT * FROM database WHERE id=?", (id_search,))
            cur.execute("UPDATE database SET comp_number=? WHERE id=?", (number, id_search))
            conn.commit()

    # Method to reset entry field
    def reset2(self):
        self.id_search.delete(0, END)
        self.first_update.delete(0, END)
        self.second_update.delete(0, END)
        self.coach_update.delete(0, END)
        self.comp_number.delete(0, END)
        self.weight_update.delete(0, END)
        self.comp_weight.delete(0, END)


# Class to delete the entry
class Delete:
    def __init__(self):
        self.win = win
        self.delete_id = Entry(win)
        self.delete_id.place(x=30, y=600)

    # Method to delete entry
    def delete_entry(self):
        try:
            id_delete = int(self.delete_id.get())
        except ValueError:
            display_error("Invalid Input!")
        else:
            conn = sqlite3.connect('database2.db')
            cur = conn.cursor()
            cur.execute("DELETE FROM database WHERE id =?", (id_delete,))
            conn.commit()

    # Method to reset entry field
    def reset3(self):
        self.delete_id.delete(0, END)


# Procedure to toggle between light and dark mode
def toggle():
    global status
    if status:
        win.config(bg="#26242f")
        status = False
    else:
        win.config(bg="white")
        status = True


def save_file():
    saveDB = Database()
    saveDB.create_database()


# Procedure to quit the program
def quit_program():
    quit()


# Procedure to create a display error box
def display_error(x):
    box.showerror("Error", x)


# Procedure to create a display message box
def display_message(x):
    box.showinfo("Info", x)


# Procedure to change the window specifications
def window_specs(title):
    win.title(title)
    win.geometry("800x800")
    win.config(bg="white")


# Procedure to display the title label
def display_label(lbl):
    label = Label(win, text=lbl, font=("Arial", 25, 'bold'))
    label.place(x=0, y=0)


# Procedure to display the input labels
def athlete_labels():
    id_label = Label(win, text="Enter ID number")
    id_label.place(x=30, y=80)
    f_label = Label(win, text="Enter first name")
    f_label.place(x=30, y=100)
    l_label = Label(win, text="Enter second name")
    l_label.place(x=30, y=120)
    plan_label = Label(win, text="Enter plan")
    plan_label.place(x=30, y=140)
    weight_label = Label(win, text="Enter weight")
    weight_label.place(x=30, y=160)
    comp_weightLabel = Label(win, text="Enter competition weight")
    comp_weightLabel.place(x=30, y=180)
    coach_label = Label(win, text="Enter coaching hours")
    coach_label.place(x=30, y=200)
    comp_numberLabel = Label(win, text="Enter number of competitions entered")
    comp_numberLabel.place(x=30, y=220)


# Procedure to display the update labels
def update_labels():
    id_searchLabel = Label(win, text="Enter ID")
    id_searchLabel.place(x=30, y=330)
    update_first = Label(win, text="Enter new first name")
    update_first.place(x=30, y=350)
    update_second = Label(win, text="Enter new second name")
    update_second.place(x=30, y=370)
    update_weight = Label(win, text="Enter new weight")
    update_weight.place(x=30, y=390)
    update_comp_weight = Label(win, text="Enter new competition weight")
    update_comp_weight.place(x=30, y=410)
    update_comp_number = Label(win, text="Enter new competition number")
    update_comp_number.place(x=30, y=430)
    update_coach = Label(win, text="Update coaching hours")
    update_coach.place(x=30, y=450)


# Procedure to display the delete id label
def delete_id():
    id_deleteLabel = Label(win, text="Enter ID to delete")
    id_deleteLabel.place(x=30, y=570)


# Creating procedure for displaying buttons
def buttons():
    db = Database()
    update = UpdateDatabase()
    delete = Delete()

    submit = Button(win, text="Submit", command=lambda: ([db.create_database(), db.weight_comparison(), db.reset()]))
    submit.place(x=30, y=300)

    update_firstName = Button(win, text="Update First Name",
                              command=lambda: ([update.update_f_name(), update.reset2()]))
    update_firstName.place(x=600, y=350)
    update_secondName = Button(win, text="Update Second Name",
                               command=lambda: ([update.update_l_name(), update.reset2()]))
    update_secondName.place(x=600, y=370)
    updateWeight = Button(win, text="Update Weight", command=lambda: ([update.update_weight(), update.reset2()]))
    updateWeight.place(x=600, y=390)
    updateCompWeight = Button(win, text="Update Competition Weight",
                              command=lambda: ([update.new_comp_weight(), update.reset2()]))
    updateCompWeight.place(x=600, y=410)
    updateCompNumber = Button(win, text="Update Competition Number",
                              command=lambda: ([update.new_compNumber(), update.reset2()]))
    updateCompNumber.place(x=600, y=430)
    updateCoach = Button(win, text="Update New Coaching Hours", command=lambda: ([update.new_coach(), update.reset2()]))
    updateCoach.place(x=600, y=450)

    updateMonth = Button(win, text="Update Month", command=lambda: ([update.new_month(), update.reset2()]))
    updateMonth.place(x=300, y=480)

    deleteButton = Button(win, text="Delete", command=lambda: ([delete.delete_entry(), delete.reset3()]))
    deleteButton.place(x=30, y=630)


# Main procedure
def main():
    window_specs("Judo")
    display_label("Judo Application")
    logo = PhotoImage(file="nlj2.png")
    win.iconphoto(True, logo)
    logo_label = Label(win, image=logo)
    logo_label.place(x=500, y=30)
    window = Window()
    window.menu_bar()
    athlete_labels()
    update_labels()
    delete_id()
    buttons()
    win.mainloop()


# Calling the main procedure
main()
