# Title: Student Information
# Author: Genesisbyte
# Date: 01-Mar-24
# Description: Creating, searching and deleting objects using OOP

# Class
class Student:
    # Creating the constructor consisting of name age address and student ID/number
    def __init__(self, stu_name, stu_age, stu_address, stu_number):
        self.name = stu_name
        self.age = stu_age
        self.address = stu_address
        self.number = stu_number
        self.stu_list = []

    # Create the function to set the data from user input
    def set_data(self):
        try:
            name = input("Enter name or q to quit: ")
            if name.lower() == "q":
                return
            age = int(input("Enter age: "))
            address = input("Enter address: ")
            number = int(input("Enter student number: "))
        except ValueError:
            print("Invalid input")
        else:
            stu = Student(name, age, address, number)  # Create an instance of Student class to be placed in list
            self.stu_list.append(stu)  # Add the instance to the list
            self.set_data()  # Use recursion to loop until q has been pressed

    # Function to show list after entering data
    # def show_data(self):
    # for details in self.stu_list:
    # print(f"{details.name},{details.age},{details.address},{details.number}")

    # Function to search in the list
    def search_list(self):
        user = int(input("Enter ID:"))
        studentsearch = [details for details in self.stu_list if
                         details.number == user]  # Check the list if id is in list
        for details in studentsearch:
            print(f"Name:{details.name},Age:{details.age},Address:{details.address},Number:{details.number}")  #
            # Print list to screen

    # Destructor to delete the objects
    def __del__(self):
        print("Object Deleted!")


# Creating the instances
student = Student("", "", "", "")
student.set_data()
# student.show_data()
student.search_list()

# Note if 2 students entered another object will be deleted eg 2 students, 3 objects deleted
# set_data has an object named stu which is considered an object
